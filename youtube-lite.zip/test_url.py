import urllib.request
try:
    code = urllib.request.urlopen("https://storage.googleapis.com/exoplayer-test-media-0/BigBuckBunny_320x180.mp4").getcode()
    print(code)
except Exception as e:
    print(e)
