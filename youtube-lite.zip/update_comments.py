import re

with open('./app/src/main/java/com/example/ui/screens/player/PlayerScreen.kt', 'r') as f:
    content = f.read()

comments_ui = """
        ModalBottomSheet(onDismissRequest = { isCommentsSheetOpen = false }, dragHandle = null, containerColor = MaterialTheme.colorScheme.background) {
            Column(modifier = Modifier.fillMaxWidth().fillMaxHeight(0.7f)) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Comments", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("1.2K", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Sort, contentDescription = "Sort", tint = MaterialTheme.colorScheme.onBackground)
                        Spacer(modifier = Modifier.width(16.dp))
                        IconButton(onClick = { isCommentsSheetOpen = false }, modifier = Modifier.size(24.dp)) {
                            Icon(Icons.Filled.Close, contentDescription = "Close", tint = MaterialTheme.colorScheme.onBackground)
                        }
                    }
                }
                Divider(color = MaterialTheme.colorScheme.surfaceVariant)
                
                // List
                LazyColumn(modifier = Modifier.weight(1f).padding(horizontal = 16.dp)) {
                    items(10) { index ->
                        Row(modifier = Modifier.padding(vertical = 12.dp)) {
                            Box(modifier = Modifier.size(36.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceVariant))
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("@user$index", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("2 days ago", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("This is a placeholder comment number $index. Really informative content!", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onBackground)
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Outlined.ThumbUp, contentDescription = "Like", modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onBackground)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("12", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Spacer(modifier = Modifier.width(16.dp))
                                    Icon(Icons.Outlined.ThumbDown, contentDescription = "Dislike", modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onBackground)
                                    Spacer(modifier = Modifier.width(16.dp))
                                    Icon(Icons.Filled.ChatBubbleOutline, contentDescription = "Reply", modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onBackground)
                                }
                            }
                        }
                    }
                }
                
                // Sticky Input Frame
                Divider(color = MaterialTheme.colorScheme.surfaceVariant)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(modifier = Modifier.size(36.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary))
                    Spacer(modifier = Modifier.width(12.dp))
                    OutlinedTextField(
                        value = "",
                        onValueChange = {},
                        placeholder = { Text("Add a comment...", style = MaterialTheme.typography.bodyMedium) },
                        modifier = Modifier.weight(1f).height(50.dp),
                        shape = MaterialTheme.shapes.large,
                        singleLine = true
                    )
                }
            }
        }
"""

content = re.sub(r'ModalBottomSheet\(onDismissRequest = \{ isCommentsSheetOpen = false \}.*?\n        \}', comments_ui.strip(), content, flags=re.DOTALL)

with open('./app/src/main/java/com/example/ui/screens/player/PlayerScreen.kt', 'w') as f:
    f.write(content)
