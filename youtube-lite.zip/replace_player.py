import re

with open('./app/src/main/java/com/example/ui/screens/player/PlayerScreen.kt', 'r') as f:
    content = f.read()

imports_to_add = """
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.annotation.OptIn
"""

content = content.replace('import androidx.compose.ui.viewinterop.AndroidView', 'import androidx.compose.ui.viewinterop.AndroidView\n' + imports_to_add)

exoplayer_init = """
    val lifecycleOwner = LocalLifecycleOwner.current
    val exoPlayer = remember {
        ExoPlayer.Builder(context).build().apply {
            repeatMode = Player.REPEAT_MODE_ALL
        }
    }
    val videoUri = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"

    LaunchedEffect(videoId) {
        val mediaItem = MediaItem.fromUri(Uri.parse(videoUri))
        exoPlayer.setMediaItem(mediaItem)
        exoPlayer.prepare()
        if (isPlaying) exoPlayer.play()
    }

    LaunchedEffect(isPlaying) {
        if (isPlaying) {
            exoPlayer.play()
        } else {
            exoPlayer.pause()
        }
    }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> {
                    if (isPlaying) exoPlayer.play()
                }
                Lifecycle.Event.ON_PAUSE -> {
                    exoPlayer.pause()
                }
                else -> {}
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    DisposableEffect(exoPlayer) {
        onDispose {
            exoPlayer.release()
        }
    }
"""

content = content.replace("var isPlaying by remember { mutableStateOf(true) }", "var isPlaying by remember { mutableStateOf(true) }\n" + exoplayer_init)

android_view_replacement = """
            AndroidView(
                factory = { ctx ->
                    @androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
                    val playerView = PlayerView(ctx).apply {
                        player = exoPlayer
                        useController = false
                        layoutParams = android.view.ViewGroup.LayoutParams(
                            android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                            android.view.ViewGroup.LayoutParams.MATCH_PARENT
                        )
                    }
                    playerView
                },
                modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)
            )
"""

android_view_regex = re.compile(r'AndroidView\(\s*factory\s*=\s*\{\s*context\s*->\s*WebView\(context\).*?\n\s*\),.*?\n\s*\)', re.DOTALL)
content = android_view_regex.sub(android_view_replacement.strip(), content)

with open('./app/src/main/java/com/example/ui/screens/player/PlayerScreen.kt', 'w') as f:
    f.write(content)

