package com.example.data.model

import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class YouTubeResponse(
    val kind: String?,
    val etag: String?,
    val items: List<VideoItem>?
)

@JsonClass(generateAdapter = true)
data class VideoItem(
    val id: Any?,
    val snippet: VideoSnippet?,
    val contentDetails: ContentDetails?,
    val statistics: Statistics?
)

@JsonClass(generateAdapter = true)
data class VideoSnippet(
    val publishedAt: String?,
    val channelId: String?,
    val title: String?,
    val description: String?,
    val thumbnails: Thumbnails?,
    val channelTitle: String?
)

@JsonClass(generateAdapter = true)
data class Thumbnails(
    val default: Thumbnail?,
    val medium: Thumbnail?,
    val high: Thumbnail?
)

@JsonClass(generateAdapter = true)
data class Thumbnail(
    val url: String?,
    val width: Int?,
    val height: Int?
)

@JsonClass(generateAdapter = true)
data class ContentDetails(
    val duration: String?
)

@JsonClass(generateAdapter = true)
data class Statistics(
    val viewCount: String?
)
