package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface WatchedVideoDao {
    @Query("SELECT * FROM watch_history ORDER BY timestamp DESC")
    fun getWatchHistory(): Flow<List<WatchedVideo>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWatchedVideo(video: WatchedVideo)

    @Query("DELETE FROM watch_history")
    suspend fun clearHistory()
}
