package com.example.data.local

import kotlinx.coroutines.flow.Flow

class VideoRepository(private val dao: DownloadedVideoDao) {
    val allDownloadedVideos: Flow<List<DownloadedVideo>> = dao.getAllDownloadedVideos()

    suspend fun insert(video: DownloadedVideo) = dao.insertDownloadedVideo(video)

    suspend fun delete(videoId: String) = dao.deleteDownloadedVideo(videoId)
}
