package com.example.data.api

import com.example.BuildConfig
import okhttp3.Interceptor
import okhttp3.Response

class ApiKeyInterceptor : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val original = chain.request()
        val originalHttpUrl = original.url
        
        // Clean up the API key if it contains the accidentally injected string or quotes
        val rawKey = BuildConfig.YOUTUBE_API_KEY
        val cleanKey = rawKey.replace("YouTube API ki  ", "").replace("\"", "").trim()

        val url = originalHttpUrl.newBuilder()
            .addQueryParameter("key", cleanKey)
            .build()

        val requestBuilder = original.newBuilder()
            .url(url)

        val request = requestBuilder.build()
        return chain.proceed(request)
    }
}
