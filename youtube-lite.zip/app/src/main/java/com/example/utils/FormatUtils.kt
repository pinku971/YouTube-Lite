package com.example.utils

import java.text.NumberFormat
import java.util.Locale

fun formatViewCount(viewCountStr: String): String {
    return try {
        val count = viewCountStr.toLong()
        when {
            count >= 1_000_000_000 -> String.format(Locale.US, "%.1fB views", count / 1_000_000_000.0)
            count >= 1_000_000 -> String.format(Locale.US, "%.1fM views", count / 1_000_000.0)
            count >= 1_000 -> String.format(Locale.US, "%.1fK views", count / 1_000.0)
            else -> "$count views"
        }
    } catch (e: Exception) {
        "$viewCountStr views"
    }
}

// Very basic duration parser for YouTube's PT#M#S format
fun formatDuration(durationStr: String): String {
    try {
        var timeStr = durationStr.replace("PT", "")
        var hours = 0
        var minutes = 0
        var seconds = 0

        if (timeStr.contains("H")) {
            val parts = timeStr.split("H")
            hours = parts[0].toInt()
            timeStr = parts[1]
        }
        if (timeStr.contains("M")) {
            val parts = timeStr.split("M")
            minutes = parts[0].toInt()
            timeStr = parts[1]
        }
        if (timeStr.contains("S")) {
            val parts = timeStr.split("S")
            seconds = parts[0].toInt()
        }

        return if (hours > 0) {
            String.format(Locale.US, "%d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format(Locale.US, "%d:%02d", minutes, seconds)
        }
    } catch (e: Exception) {
        return "0:00"
    }
}
