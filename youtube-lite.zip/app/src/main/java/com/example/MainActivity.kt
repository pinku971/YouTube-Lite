package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import com.example.data.preferences.UserPreferences
import com.example.ui.YouTubeLiteApp
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        
        val userPreferences = UserPreferences(this)
        
        setContent {
            val systemTheme = isSystemInDarkTheme()
            val userThemeFlow = remember { userPreferences.darkModeFlow }
            val isDarkUserPref by userThemeFlow.collectAsState(initial = null)
            
            val isDarkMode = isDarkUserPref ?: systemTheme
            val coroutineScope = rememberCoroutineScope()

            MyApplicationTheme(darkTheme = isDarkMode) {
                YouTubeLiteApp(
                    isDarkMode = isDarkMode,
                    onThemeToggle = { dark ->
                        coroutineScope.launch {
                            userPreferences.setDarkMode(dark)
                        }
                    }
                )
            }
        }
    }
}

