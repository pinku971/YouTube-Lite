package com.example.ui.components

import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.viewinterop.AndroidView

@Composable
fun ShortVideoPlayer(videoId: String, isPlaying: Boolean) {
    Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
        if (isPlaying) {
            AndroidView(
                factory = { context ->
                    WebView(context).apply {
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.mediaPlaybackRequiresUserGesture = false
                        webViewClient = WebViewClient()
                        webChromeClient = WebChromeClient()
                        // YouTube Shorts url parameter: loop=1&playlist=$videoId
                        val html = """
                            <!DOCTYPE html>
                            <html>
                                <head>
                                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                                    <style>
                                        body { margin: 0; padding: 0; background-color: black; }
                                        iframe { width: 100vw; height: 100vh; border: none; pointer-events: none; }
                                    </style>
                                </head>
                                <body>
                                    <iframe src="https://www.youtube.com/embed/$videoId?autoplay=1&loop=1&playlist=$videoId&controls=0&modestbranding=1&rel=0&showinfo=0&iv_load_policy=3&mute=0" allow="autoplay; fullscreen" allowfullscreen></iframe>
                                </body>
                            </html>
                        """.trimIndent()
                        loadDataWithBaseURL("https://www.youtube.com", html, "text/html", "utf-8", null)
                    }
                },
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}
