package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun YouTubeLogo(
    iconSize: Dp = 24.dp,
    textSize: Float = 20f,
    showText: Boolean = true
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Canvas(modifier = Modifier.size(width = iconSize * 1.4f, height = iconSize)) {
            val redColor = Color(0xFFFF0000)
            val whiteColor = Color.White
            
            // Draw the red rounded rectangle
            drawRoundRect(
                color = redColor,
                size = Size(width = size.width, height = size.height),
                cornerRadius = CornerRadius(size.height * 0.25f, size.height * 0.25f)
            )
            
            // Draw the white play triangle
            val trianglePath = Path().apply {
                val triangleWidth = size.width * 0.35f
                val triangleHeight = size.height * 0.45f
                val startX = (size.width - triangleWidth) / 2f + size.width * 0.05f
                val startY = (size.height - triangleHeight) / 2f
                
                moveTo(startX, startY)
                lineTo(startX + triangleWidth, startY + triangleHeight / 2f)
                lineTo(startX, startY + triangleHeight)
                close()
            }
            drawPath(path = trianglePath, color = whiteColor)
        }
        
        if (showText) {
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = "YouTube",
                fontSize = textSize.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface,
                letterSpacing = (-1).sp
            )
        }
    }
}
