package com.example.ui.screens.home

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.BuildConfig
import com.example.data.api.RetrofitClient
import com.example.data.model.VideoItem
import com.example.ui.components.CategoryChips
import com.example.ui.components.TopBar
import com.example.ui.components.VideoItemCard
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun HomeScreen(
    onVideoClick: (String) -> Unit,
    onSearchClick: () -> Unit
) {
    var videos by remember { mutableStateOf<List<VideoItem>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var currentCategory by remember { mutableStateOf("All") }

    LaunchedEffect(currentCategory) {
        isLoading = true
        errorMessage = null
        try {
            
            if (BuildConfig.YOUTUBE_API_KEY == "MY_YOUTUBE_API_KEY" || BuildConfig.YOUTUBE_API_KEY.isBlank()) {
                errorMessage = "Please configure your YOUTUBE_API_KEY in the Secrets panel."
                isLoading = false
                return@LaunchedEffect
            }
            
            val response = withContext(Dispatchers.IO) {
                if (currentCategory == "All") {
                    RetrofitClient.apiService.getPopularVideos()
                } else {
                    RetrofitClient.apiService.searchVideos(query = currentCategory)
                }
            }
            videos = response.items ?: emptyList()
            isLoading = false
        } catch (e: Exception) {
            errorMessage = e.message ?: "An error occurred"
            isLoading = false
        }
    }

    Column(modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        TopBar(
            onSearchClick = onSearchClick
        )
        
        CategoryChips(onCategorySelected = { category ->
            currentCategory = category
        })

        Box(modifier = Modifier.fillMaxSize()) {
            when {
                isLoading -> {
                    androidx.compose.foundation.lazy.LazyColumn(modifier = Modifier.fillMaxSize()) {
                        items(5) {
                            com.example.ui.components.VideoItemSkeleton()
                        }
                    }
                }
                errorMessage != null -> {
                    Text(
                        text = errorMessage ?: "Error",
                        modifier = Modifier.align(Alignment.Center).padding(16.dp),
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }
                else -> {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(videos) { video ->
                            VideoItemCard(
                                video = video,
                                onClick = {
                                    val videoId = if (video.id is String) video.id else (video.id as? Map<*, *>)?.get("videoId")?.toString()
                                    videoId?.let { onVideoClick(it) }
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}
