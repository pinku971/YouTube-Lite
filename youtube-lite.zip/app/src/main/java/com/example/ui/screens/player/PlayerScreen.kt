
package com.example.ui.screens.player

import androidx.compose.ui.unit.IntOffset
import kotlin.math.roundToInt
import android.app.Activity
import android.content.pm.ActivityInfo
import androidx.compose.ui.platform.LocalContext
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material3.OutlinedTextField
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll

import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ThumbDown
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView

import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView


import com.example.BuildConfig
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.ui.draw.scale
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Environment
import kotlinx.coroutines.launch
import androidx.compose.material.icons.outlined.ThumbUp
import androidx.compose.material.icons.outlined.ThumbDown
import com.example.ui.components.CategoryChips
import com.example.data.api.RetrofitClient
import com.example.data.model.VideoItem
import com.example.ui.components.VideoItemCard
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlayerOverlay(
    videoId: String,
    isExpanded: Boolean,
    hasPrevious: Boolean = false,
    onExpand: () -> Unit,
    onMinimize: () -> Unit,
    onClose: () -> Unit,
    onVideoClick: (String) -> Unit,
    onPreviousClick: () -> Unit = {}
) {
    var videoDetails by remember(videoId) { mutableStateOf<VideoItem?>(null) }
    var recommendedVideos by remember(videoId) { mutableStateOf<List<VideoItem>>(emptyList()) }
    var isLoading by remember(videoId) { mutableStateOf(true) }
    var errorMessage by remember(videoId) { mutableStateOf<String?>(null) }
    var isDescriptionSheetOpen by remember { mutableStateOf(false) }
    
    var isPlaying by remember { mutableStateOf(true) }

    val lifecycleOwner = LocalLifecycleOwner.current
    val context = LocalContext.current
    val exoPlayer = remember {
        ExoPlayer.Builder(context).build().apply {
            repeatMode = Player.REPEAT_MODE_ALL
        }
    }
    val videoUri = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"

    LaunchedEffect(videoId) {
        val mediaItem = MediaItem.fromUri(Uri.parse(videoUri))
        exoPlayer.setMediaItem(mediaItem)
        exoPlayer.prepare()
        if (isPlaying) exoPlayer.play()
    }

    LaunchedEffect(isPlaying) {
        if (isPlaying) {
            exoPlayer.play()
        } else {
            exoPlayer.pause()
        }
    }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> {
                    if (isPlaying) exoPlayer.play()
                }
                Lifecycle.Event.ON_PAUSE -> {
                    exoPlayer.pause()
                }
                else -> {}
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    DisposableEffect(exoPlayer) {
        onDispose {
            exoPlayer.release()
        }
    }

    var webViewRef by remember { mutableStateOf<WebView?>(null) }
    var showControls by remember { mutableStateOf(true) }
    
    var isFullscreen by remember { mutableStateOf(false) }

    var isCommentsSheetOpen by remember { mutableStateOf(false) }
    var offsetX by remember { mutableStateOf(0f) }
    var offsetY by remember { mutableStateOf(0f) }

    BackHandler(enabled = isExpanded) {
        onMinimize()
    }

    LaunchedEffect(isExpanded) {
        if (isExpanded) {
            offsetX = 0f
            offsetY = 0f
        } else {
            isFullscreen = false
            (context as? Activity)?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }

    LaunchedEffect(videoId) {
        try {
            val apiKey = BuildConfig.YOUTUBE_API_KEY
            if (apiKey == "MY_YOUTUBE_API_KEY" || apiKey.isBlank()) {
                errorMessage = "Please configure your YOUTUBE_API_KEY."
                isLoading = false
                return@LaunchedEffect
            }
            val detailsResponse = withContext(Dispatchers.IO) {
                RetrofitClient.apiService.getVideoDetails(id = videoId, apiKey = apiKey)
            }
            videoDetails = detailsResponse.items?.firstOrNull()
            
            videoDetails?.let { details ->
                val title = details.snippet?.title ?: "Unknown Title"
                val channelName = details.snippet?.channelTitle ?: "YouTube Channel"
                val thumbnailUrl = details.snippet?.thumbnails?.high?.url ?: ""
                val viewCount = details.statistics?.viewCount ?: "0"
                
                val db = com.example.data.local.AppDatabase.getDatabase(context)
                val scope = kotlinx.coroutines.CoroutineScope(Dispatchers.IO)
                scope.launch {
                    db.watchedVideoDao().insertWatchedVideo(
                        com.example.data.local.WatchedVideo(
                            videoId = videoId,
                            title = title,
                            channelName = channelName,
                            thumbnailUrl = thumbnailUrl,
                            viewCount = viewCount
                        )
                    )
                }
            }
            
            val recommendedResponse = withContext(Dispatchers.IO) {
                RetrofitClient.apiService.searchVideos(query = videoDetails?.snippet?.title ?: "Music", apiKey = apiKey)
            }
            recommendedVideos = recommendedResponse.items ?: emptyList()
            
            isLoading = false
        } catch (e: Exception) {
            errorMessage = e.message ?: "An error occurred"
            isLoading = false
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        if (isExpanded && !isFullscreen) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
                    .pointerInput(Unit) {
                        detectDragGestures { change, dragAmount ->
                            if (dragAmount.y > 50) {
                                onMinimize()
                            }
                        }
                    }
            ) {
                // Spacer for player
                Spacer(modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f))
                
                Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                    when {
                        isLoading -> {
                            CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
                        }
                        errorMessage != null -> {
                            Text(
                                text = errorMessage ?: "Error",
                                color = MaterialTheme.colorScheme.error,
                                modifier = Modifier.align(Alignment.Center).padding(16.dp)
                            )
                        }
                        else -> {
                            LazyColumn(modifier = Modifier.fillMaxSize()) {
                                item {
                                    videoDetails?.let { details ->
                                        Column(modifier = Modifier.padding(16.dp)) {
                                            val title = details.snippet?.title ?: "Unknown Title"
                                            val views = details.statistics?.viewCount ?: "0"
                                            val date = details.snippet?.publishedAt?.take(10) ?: ""
                                            val channelName = details.snippet?.channelTitle ?: "YouTube Channel"
                                            
                                            // Title Section (Clickable for description)
                                            Column(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .clickable { isDescriptionSheetOpen = true }
                                                    .padding(vertical = 8.dp)
                                            ) {
                                                Text(
                                                    text = title,
                                                    style = MaterialTheme.typography.titleMedium,
                                                    fontWeight = FontWeight.Bold,
                                                    color = MaterialTheme.colorScheme.onBackground
                                                )
                                                Spacer(modifier = Modifier.height(4.dp))
                                                Text(
                                                    text = "$views views • $date ...more",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
                                                )
                                            }
                                            
                                            Spacer(modifier = Modifier.height(8.dp))
                                            
                                            // Channel & Subscribe Row
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(40.dp)
                                                        .clip(CircleShape)
                                                        .background(MaterialTheme.colorScheme.surfaceVariant),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Icon(Icons.Filled.Person, contentDescription = "Channel", tint = MaterialTheme.colorScheme.onBackground)
                                                }
                                                Spacer(modifier = Modifier.width(12.dp))
                                                Text(
                                                    text = channelName,
                                                    style = MaterialTheme.typography.bodyMedium,
                                                    fontWeight = FontWeight.Bold,
                                                    color = MaterialTheme.colorScheme.onBackground,
                                                    modifier = Modifier.weight(1f)
                                                )
                                                Box(
                                                    modifier = Modifier
                                                        .clip(CircleShape)
                                                        .background(MaterialTheme.colorScheme.onBackground)
                                                        .clickable { /* Subscribe */ }
                                                        .padding(horizontal = 16.dp, vertical = 8.dp)
                                                ) {
                                                    Text(
                                                        text = "Subscribe",
                                                        color = MaterialTheme.colorScheme.background,
                                                        style = MaterialTheme.typography.labelLarge,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                }
                                            }
                                            
                                            Spacer(modifier = Modifier.height(16.dp))
                                            
                                            // Action Bar
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceEvenly
                                            ) {
                                                LikeButton()
                                                DislikeButton()
                                                ActionBarItem(icon = Icons.Filled.Share, label = "Share", onClick = {
                                                    val sendIntent = Intent().apply {
                                                        action = Intent.ACTION_SEND
                                                        putExtra(Intent.EXTRA_TEXT, "Check out this video: https://www.youtube.com/watch?v=$videoId")
                                                        type = "text/plain"
                                                    }
                                                    context.startActivity(Intent.createChooser(sendIntent, "Share video via"))
                                                })
                                                ActionBarItem(icon = Icons.Filled.Download, label = "Download", onClick = {
                                                    try {
                                                        // Insert into database
                                                        val db = com.example.data.local.AppDatabase.getDatabase(context)
                                                        val scope = kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO)
                                                        scope.launch {
                                                            db.downloadedVideoDao().insertDownloadedVideo(
                                                                com.example.data.local.DownloadedVideo(
                                                                    videoId = videoId,
                                                                    title = title,
                                                                    channelName = channelName,
                                                                    thumbnailUrl = details.snippet?.thumbnails?.high?.url ?: "",
                                                                    localUri = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).absolutePath + "/video_$videoId.mp4"
                                                                )
                                                            )
                                                        }
                                                        
                                                        android.widget.Toast.makeText(context, "Downloading video...", android.widget.Toast.LENGTH_SHORT).show()
                                                        
                                                        val request = DownloadManager.Request(Uri.parse("https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"))
                                                            .setTitle("Downloading Video")
                                                            .setDescription("Downloading video $videoId")
                                                            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                                                            .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "video_$videoId.mp4")
                                                        
                                                        val downloadManager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                                                        downloadManager.enqueue(request)
                                                    } catch (e: Exception) {
                                                        e.printStackTrace()
                                                    }
                                                })
                                            }
                                            
                                            Spacer(modifier = Modifier.height(16.dp))
                                            
                                            // Comment Preview Box
                                            Box(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .clip(MaterialTheme.shapes.medium)
                                                    .background(MaterialTheme.colorScheme.onBackground.copy(alpha = 0.1f))
                                                    .clickable { isCommentsSheetOpen = true }
                                                    .padding(12.dp)
                                            ) {
                                                Column {
                                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                                        Text(
                                                            text = "Comments",
                                                            style = MaterialTheme.typography.titleSmall,
                                                            fontWeight = FontWeight.Bold,
                                                            color = MaterialTheme.colorScheme.onBackground
                                                        )
                                                        Spacer(modifier = Modifier.width(8.dp))
                                                        Text(
                                                            text = "1.2K",
                                                            style = MaterialTheme.typography.bodySmall,
                                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                                        )
                                                    }
                                                    Spacer(modifier = Modifier.height(8.dp))
                                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                                        Box(
                                                            modifier = Modifier
                                                                .size(24.dp)
                                                                .clip(CircleShape)
                                                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                                        )
                                                        Spacer(modifier = Modifier.width(8.dp))
                                                        Text(
                                                            text = "This is a great video! Thanks for sharing.",
                                                            style = MaterialTheme.typography.bodySmall,
                                                            color = MaterialTheme.colorScheme.onBackground,
                                                            maxLines = 1
                                                        )
                                                    }
                                                }
                                            }
                                            
                                            Spacer(modifier = Modifier.height(16.dp))
                                        }
                                    }
                                }
                                
                                item {
                                    CategoryChips(onCategorySelected = { category ->
                                        // You could filter recommended videos here
                                    })
                                }
                                
                                items(recommendedVideos) { video ->
                                    VideoItemCard(
                                        video = video,
                                        onClick = {
                                            val recVideoId = if (video.id is String) video.id.toString() else (video.id as? Map<*, *>)?.get("videoId")?.toString()
                                            recVideoId?.let { onVideoClick(it) }
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // The Video Player (Shared between Expanded and Minimized)
        val playerModifier = if (!isExpanded) {
            Modifier
                .align(Alignment.BottomEnd)
                .offset { IntOffset(offsetX.roundToInt(), offsetY.roundToInt()) }
                .padding(bottom = 80.dp, end = 16.dp)
                .width(160.dp)
                .aspectRatio(16f / 9f)
                .clip(MaterialTheme.shapes.medium)
        } else if (isFullscreen) {
            Modifier.fillMaxSize()
        } else {
            Modifier.fillMaxWidth().aspectRatio(16f / 9f).align(Alignment.TopCenter)
        }

        Box(
            modifier = playerModifier
                .then(
                    if (!isExpanded) {
                        Modifier.pointerInput(Unit) {
                            detectDragGestures { change, dragAmount ->
                                change.consume()
                                offsetX += dragAmount.x
                                offsetY += dragAmount.y
                            }
                        }
                    } else {
                        Modifier
                    }
                )
                .clickable { 
                    if (!isExpanded) {
                        onExpand()
                    } else {
                        showControls = !showControls 
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            AndroidView(
                factory = { context ->
                    WebView(context).apply {
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.mediaPlaybackRequiresUserGesture = false
                        webViewClient = WebViewClient()
                        webChromeClient = WebChromeClient()
                        webViewRef = this
                        val html = """
                            <!DOCTYPE html>
                            <html>
                                <head>
                                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                                    <style>
                                        body { margin: 0; padding: 0; background-color: black; }
                                        iframe { width: 100vw; height: 100vh; border: none; pointer-events: none; }
                                    </style>
                                </head>
                                <body>
                                    <iframe src="https://www.youtube.com/embed/$videoId?autoplay=1&enablejsapi=1&rel=0&modestbranding=1&controls=0" allow="autoplay; fullscreen" allowfullscreen></iframe>
                                </body>
                            </html>
                        """.trimIndent()
                        loadDataWithBaseURL("https://www.youtube.com", html, "text/html", "utf-8", null)
                    }
                },
                modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background),
                update = { webView ->
                    webViewRef = webView
                    val html = """
                        <!DOCTYPE html>
                        <html>
                            <head>
                                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                                <style>
                                    body { margin: 0; padding: 0; background-color: black; }
                                    iframe { width: 100vw; height: 100vh; border: none; pointer-events: none; }
                                </style>
                            </head>
                            <body>
                                <iframe src="https://www.youtube.com/embed/$videoId?autoplay=1&enablejsapi=1&rel=0&modestbranding=1&controls=0" allow="autoplay; fullscreen" allowfullscreen></iframe>
                            </body>
                        </html>
                    """.trimIndent()
                    webView.loadDataWithBaseURL("https://www.youtube.com", html, "text/html", "utf-8", null)
                    isPlaying = true
                }
            )

            // Player Controls Overlay
            if (showControls) {
                // Dim background
                Box(modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background.copy(alpha = 0.4f)))
                
                Row(
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { onPreviousClick() }, enabled = hasPrevious) {
                        Icon(
                            imageVector = Icons.Filled.SkipPrevious,
                            contentDescription = "Previous",
                            tint = if (hasPrevious) MaterialTheme.colorScheme.onBackground else Color.Gray,
                            modifier = Modifier.size(if (isExpanded) 32.dp else 24.dp)
                        )
                    }
                    
                    Spacer(modifier = Modifier.width(if (isExpanded) 24.dp else 8.dp))
                    
                    IconButton(
                        onClick = {
                            isPlaying = !isPlaying
                            val command = if (isPlaying) "playVideo" else "pauseVideo"
                            webViewRef?.evaluateJavascript("document.querySelector('iframe').contentWindow.postMessage('{\"event\":\"command\",\"func\":\"$command\",\"args\":\"\"}', '*');", null)
                        }
                    ) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                            contentDescription = if (isPlaying) "Pause" else "Play",
                            tint = MaterialTheme.colorScheme.onBackground,
                            modifier = Modifier.size(if (isExpanded) 48.dp else 32.dp)
                        )
                    }
                    
                    Spacer(modifier = Modifier.width(if (isExpanded) 24.dp else 8.dp))
                    
                    IconButton(
                        onClick = { 
                            if (recommendedVideos.isNotEmpty()) {
                                val nextVideoId = if (recommendedVideos[0].id is String) recommendedVideos[0].id.toString() else (recommendedVideos[0].id as? Map<*, *>)?.get("videoId")?.toString()
                                nextVideoId?.let { onVideoClick(it) }
                            }
                        },
                        enabled = recommendedVideos.isNotEmpty()
                    ) {
                        Icon(
                            imageVector = Icons.Filled.SkipNext,
                            contentDescription = "Next",
                            tint = if (recommendedVideos.isNotEmpty()) MaterialTheme.colorScheme.onBackground else Color.Gray,
                            modifier = Modifier.size(if (isExpanded) 32.dp else 24.dp)
                        )
                    }
                }

                if (isExpanded) {
                    // Fullscreen toggle
                    IconButton(
                        onClick = {
                            isFullscreen = !isFullscreen
                            (context as? Activity)?.requestedOrientation = if (isFullscreen) {
                                ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                            } else {
                                ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                            }
                        },
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(8.dp)
                    ) {
                        Icon(
                            imageVector = if (isFullscreen) Icons.Filled.FullscreenExit else Icons.Filled.Fullscreen,
                            contentDescription = "Fullscreen",
                            tint = MaterialTheme.colorScheme.onBackground
                        )
                    }
                }
            }

            if (!isExpanded) {
                // Expand interceptor layer above controls but passing clicks if we need, or we let the controls handle clicks.
                // Since the user wants to expand it, let's put an expand button or just expand when touching non-button areas.
                // We handled that by making the parent Box clickable. But icon buttons will consume the click.
                
                // Close button
                IconButton(
                    onClick = onClose,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(4.dp)
                        .size(24.dp)
                        .background(MaterialTheme.colorScheme.background.copy(alpha = 0.6f), CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Close,
                        contentDescription = "Close",
                        tint = MaterialTheme.colorScheme.onBackground,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }

    if (isDescriptionSheetOpen) {
        ModalBottomSheet(onDismissRequest = { isDescriptionSheetOpen = false }) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight(0.9f)
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Description",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    IconButton(onClick = { isDescriptionSheetOpen = false }) {
                        Icon(Icons.Filled.Close, contentDescription = "Close", tint = MaterialTheme.colorScheme.onBackground)
                    }
                }
                
                Column(modifier = Modifier.fillMaxWidth().weight(1f).verticalScroll(rememberScrollState())) {
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    Text(
                        text = "${videoDetails?.statistics?.viewCount ?: "0"} views  •  ${videoDetails?.snippet?.publishedAt?.take(10) ?: ""}",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    Text(
                        text = videoDetails?.snippet?.description ?: "No description available.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    
                    Spacer(modifier = Modifier.height(32.dp))
                }
            }
        }
    }

    if (isCommentsSheetOpen) {
        ModalBottomSheet(onDismissRequest = { isCommentsSheetOpen = false }) {
            Column(modifier = Modifier.fillMaxWidth().fillMaxHeight(0.7f).padding(16.dp)) {
                Text("Comments", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                Spacer(modifier = Modifier.height(16.dp))
                LazyColumn(modifier = Modifier.weight(1f)) {
                    items(10) { index ->
                        Row(modifier = Modifier.padding(vertical = 8.dp)) {
                            Box(modifier = Modifier.size(32.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceVariant))
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text("User $index", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                                Spacer(modifier = Modifier.height(2.dp))
                                Text("This is a placeholder comment number $index. Really informative content!", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
                // Input box
                OutlinedTextField(
                    value = "",
                    onValueChange = {},
                    placeholder = { Text("Add a comment...") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = MaterialTheme.shapes.large
                )
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}

@Composable
fun ActionBarItem(icon: ImageVector, label: String, onClick: () -> Unit = {}) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clickable { onClick() }
    ) {
        Icon(imageVector = icon, contentDescription = label, tint = MaterialTheme.colorScheme.onBackground)
        Spacer(modifier = Modifier.height(4.dp))
        Text(text = label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onBackground)
    }
}

@Composable
fun LikeButton() {
    var isLiked by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        targetValue = if (isLiked) 1.2f else 1f,
        animationSpec = tween(durationMillis = 200),
        label = "likeScale"
    )
    
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clickable { isLiked = !isLiked }
    ) {
        Icon(
            imageVector = if (isLiked) Icons.Filled.ThumbUp else Icons.Outlined.ThumbUp,
            contentDescription = "Like",
            tint = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.scale(if (isLiked) scale else 1f)
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(text = "Like", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onBackground)
    }
}

@Composable
fun DislikeButton() {
    var isDisliked by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        targetValue = if (isDisliked) 1.2f else 1f,
        animationSpec = tween(durationMillis = 200),
        label = "dislikeScale"
    )
    
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clickable { isDisliked = !isDisliked }
    ) {
        Icon(
            imageVector = if (isDisliked) Icons.Filled.ThumbDown else Icons.Outlined.ThumbDown,
            contentDescription = "Dislike",
            tint = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier.scale(if (isDisliked) scale else 1f)
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(text = "Dislike", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onBackground)
    }
}
