package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val PremiumBlack = Color(0xFF000000)
val PremiumSurface = Color(0xFF121212)
val PremiumSurfaceVariant = Color(0xFF1E1E1E)
val PremiumWhite = Color(0xFFFFFFFF)
val PremiumMutedGrey = Color(0xFFAAAAAA)
val PremiumRed = Color(0xFFFF0000)

private val DarkColorScheme = darkColorScheme(
    primary = PremiumWhite,
    onPrimary = PremiumBlack,
    primaryContainer = PremiumSurfaceVariant,
    onPrimaryContainer = PremiumWhite,
    secondary = PremiumRed,
    onSecondary = PremiumWhite,
    background = PremiumBlack,
    onBackground = PremiumWhite,
    surface = PremiumSurface,
    onSurface = PremiumWhite,
    surfaceVariant = PremiumSurfaceVariant,
    onSurfaceVariant = PremiumMutedGrey,
    error = PremiumRed,
    onError = PremiumWhite
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Force dark theme
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography, // We'll update Typography next if needed
        content = content
    )
}
