package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val PremiumBlack = Color(0xFF000000)
val PremiumSurface = Color(0xFF121212)
val PremiumSurfaceVariant = Color(0xFF1E1E1E)
val PremiumWhite = Color(0xFFFFFFFF)
val PremiumMutedGrey = Color(0xFFAAAAAA)
val PremiumRed = Color(0xFFFF0000)

val LightBackground = Color(0xFFF9F9F9)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE5E5E5)
val LightMutedGrey = Color(0xFF606060)

private val DarkColorScheme = darkColorScheme(
    primary = PremiumWhite,
    onPrimary = PremiumBlack,
    primaryContainer = PremiumSurfaceVariant,
    onPrimaryContainer = PremiumWhite,
    secondary = PremiumRed,
    onSecondary = PremiumWhite,
    background = PremiumBlack,
    onBackground = PremiumWhite,
    surface = PremiumSurface,
    onSurface = PremiumWhite,
    surfaceVariant = PremiumSurfaceVariant,
    onSurfaceVariant = PremiumMutedGrey,
    error = PremiumRed,
    onError = PremiumWhite
)

private val LightColorScheme = lightColorScheme(
    primary = PremiumBlack,
    onPrimary = PremiumWhite,
    primaryContainer = LightSurfaceVariant,
    onPrimaryContainer = PremiumBlack,
    secondary = PremiumRed,
    onSecondary = PremiumWhite,
    background = LightBackground,
    onBackground = PremiumBlack,
    surface = LightSurface,
    onSurface = PremiumBlack,
    surfaceVariant = LightSurfaceVariant,
    onSurfaceVariant = LightMutedGrey,
    error = PremiumRed,
    onError = PremiumWhite
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
