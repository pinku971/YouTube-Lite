package com.example.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Comment
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ThumbDown
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
fun ShortsOverlayControls(modifier: Modifier = Modifier) {
    Column(
        modifier = modifier.padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(24.dp)
    ) {
        IconButton(onClick = { /* Like */ }) {
            Icon(Icons.Filled.ThumbUp, contentDescription = "Like", tint = Color.White)
        }
        IconButton(onClick = { /* Dislike */ }) {
            Icon(Icons.Filled.ThumbDown, contentDescription = "Dislike", tint = Color.White)
        }
        IconButton(onClick = { /* Comment */ }) {
            Icon(Icons.Filled.Comment, contentDescription = "Comment", tint = Color.White)
        }
        IconButton(onClick = { /* Share */ }) {
            Icon(Icons.Filled.Share, contentDescription = "Share", tint = Color.White)
        }
    }
}
