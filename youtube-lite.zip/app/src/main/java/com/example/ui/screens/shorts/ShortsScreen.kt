package com.example.ui.screens.shorts

import android.content.Intent
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Comment
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ThumbDown
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.outlined.ThumbDown
import androidx.compose.material.icons.outlined.ThumbUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.BuildConfig
import com.example.data.api.RetrofitClient
import com.example.data.model.VideoItem
import com.example.ui.components.ShortVideoPlayer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)
@Composable
fun ShortsScreen() {
    var shorts by remember { mutableStateOf<List<VideoItem>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var showCommentsSheet by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        try {
            val apiKey = BuildConfig.YOUTUBE_API_KEY
            if (apiKey == "MY_YOUTUBE_API_KEY" || apiKey.isBlank()) {
                errorMessage = "Please configure your YOUTUBE_API_KEY."
                isLoading = false
                return@LaunchedEffect
            }
            
            val response = withContext(Dispatchers.IO) {
                RetrofitClient.apiService.searchVideos(query = "#shorts", apiKey = apiKey)
            }
            shorts = response.items ?: emptyList()
            isLoading = false
        } catch (e: Exception) {
            errorMessage = e.message ?: "An error occurred"
            isLoading = false
        }
    }

    Box(modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        when {
            isLoading -> {
                CircularProgressIndicator(modifier = Modifier.align(Alignment.Center), color = MaterialTheme.colorScheme.onBackground)
            }
            errorMessage != null -> {
                Text(
                    text = errorMessage ?: "Error",
                    color = MaterialTheme.colorScheme.onBackground,
                    modifier = Modifier.align(Alignment.Center).padding(16.dp)
                )
            }
            shorts.isEmpty() -> {
                Text(
                    text = "No shorts found",
                    color = MaterialTheme.colorScheme.onBackground,
                    modifier = Modifier.align(Alignment.Center).padding(16.dp)
                )
            }
            else -> {
                val pagerState = rememberPagerState(pageCount = { shorts.size })
                
                VerticalPager(
                    state = pagerState,
                    modifier = Modifier.fillMaxSize()
                ) { page ->
                    val video = shorts[page]
                    val videoId = if (video.id is String) video.id.toString() else (video.id as? Map<*, *>)?.get("videoId")?.toString() ?: ""
                    
                    Box(modifier = Modifier.fillMaxSize()) {
                        ShortVideoPlayer(
                            videoId = videoId,
                            isPlaying = pagerState.currentPage == page
                        )
                        
                        // Dark gradient overlay for text readability (bottom half)
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .fillMaxHeight(0.6f)
                                .align(Alignment.BottomCenter)
                                .background(
                                    Brush.verticalGradient(
                                        colors = listOf(Color.Transparent, MaterialTheme.colorScheme.background.copy(alpha = 0.8f))
                                    )
                                )
                        )
                        
                        val title = video.snippet?.title ?: ""
                        val channelName = video.snippet?.channelTitle ?: "Channel"
                        val thumbnailUrl = video.snippet?.thumbnails?.default?.url ?: ""

                        // Bottom Info Overlay (Left-Aligned)
                        Column(
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(start = 16.dp, bottom = 16.dp, end = 80.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                AsyncImage(
                                    model = thumbnailUrl,
                                    contentDescription = "Profile",
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colorScheme.surfaceVariant)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "@${channelName.replace(" ", "")}",
                                    color = MaterialTheme.colorScheme.onBackground,
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                
                                var isSubscribed by remember { mutableStateOf(false) }
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(16.dp))
                                        .background(if (isSubscribed) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.onBackground)
                                        .clickable { isSubscribed = !isSubscribed }
                                        .padding(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Text(
                                        text = if (isSubscribed) "Subscribed" else "Subscribe",
                                        color = if (isSubscribed) MaterialTheme.colorScheme.onBackground else MaterialTheme.colorScheme.background,
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.labelMedium
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = title,
                                color = MaterialTheme.colorScheme.onBackground,
                                style = MaterialTheme.typography.bodyMedium,
                                maxLines = 2
                            )
                        }
                        
                        // Right-Side Vertical Action Bar
                        ShortsOverlayControls(
                            videoId = videoId,
                            thumbnailUrl = thumbnailUrl,
                            onCommentClick = { showCommentsSheet = true },
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(end = 16.dp, bottom = 16.dp)
                        )
                    }
                }
            }
        }
    }

    if (showCommentsSheet) {
        ModalBottomSheet(onDismissRequest = { showCommentsSheet = false }) {
            Column(modifier = Modifier.fillMaxWidth().fillMaxHeight(0.6f).padding(16.dp)) {
                Text("Comments", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(16.dp))
                LazyColumn(modifier = Modifier.weight(1f)) {
                    items(10) { index ->
                        Row(modifier = Modifier.padding(vertical = 8.dp)) {
                            Box(modifier = Modifier.size(32.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceVariant))
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text("User $index", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.height(2.dp))
                                Text("Great short! Loved it.", style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                    }
                }
                OutlinedTextField(
                    value = "",
                    onValueChange = {},
                    placeholder = { Text("Add a comment...") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}

@Composable
fun ShortsOverlayControls(
    videoId: String,
    thumbnailUrl: String,
    onCommentClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        // Like Button
        var isLiked by remember { mutableStateOf(false) }
        var likeCount by remember { mutableStateOf(12400) }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            IconButton(onClick = { 
                isLiked = !isLiked
                if (isLiked) likeCount++ else likeCount--
            }) {
                Icon(
                    imageVector = if (isLiked) Icons.Filled.ThumbUp else Icons.Outlined.ThumbUp, 
                    contentDescription = "Like", 
                    tint = MaterialTheme.colorScheme.onBackground,
                    modifier = Modifier.size(32.dp)
                )
            }
            Text(
                text = formatCount(likeCount),
                color = MaterialTheme.colorScheme.onBackground,
                style = MaterialTheme.typography.labelMedium
            )
        }
        
        // Dislike Button
        var isDisliked by remember { mutableStateOf(false) }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            IconButton(onClick = { isDisliked = !isDisliked }) {
                Icon(
                    imageVector = if (isDisliked) Icons.Filled.ThumbDown else Icons.Outlined.ThumbDown, 
                    contentDescription = "Dislike", 
                    tint = MaterialTheme.colorScheme.onBackground,
                    modifier = Modifier.size(32.dp)
                )
            }
            Text(
                text = "Dislike",
                color = MaterialTheme.colorScheme.onBackground,
                style = MaterialTheme.typography.labelMedium
            )
        }
        
        // Comment Button
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            IconButton(onClick = onCommentClick) {
                Icon(
                    imageVector = Icons.Filled.Comment, 
                    contentDescription = "Comment", 
                    tint = MaterialTheme.colorScheme.onBackground,
                    modifier = Modifier.size(32.dp)
                )
            }
            Text(
                text = "456",
                color = MaterialTheme.colorScheme.onBackground,
                style = MaterialTheme.typography.labelMedium
            )
        }
        
        // Share Button
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            IconButton(onClick = {
                val sendIntent = Intent().apply {
                    action = Intent.ACTION_SEND
                    putExtra(Intent.EXTRA_TEXT, "Check out this short: https://www.youtube.com/shorts/$videoId")
                    type = "text/plain"
                }
                context.startActivity(Intent.createChooser(sendIntent, "Share short via"))
            }) {
                Icon(
                    imageVector = Icons.Filled.Share, 
                    contentDescription = "Share", 
                    tint = MaterialTheme.colorScheme.onBackground,
                    modifier = Modifier.size(32.dp)
                )
            }
            Text(
                text = "Share",
                color = MaterialTheme.colorScheme.onBackground,
                style = MaterialTheme.typography.labelMedium
            )
        }
        
        // Audio/Remix Profile
        AsyncImage(
            model = thumbnailUrl,
            contentDescription = "Audio Profile",
            modifier = Modifier
                .size(40.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
        )
    }
}

fun formatCount(count: Int): String {
    return when {
        count >= 1000000 -> String.format("%.1fM", count / 1000000.0)
        count >= 1000 -> String.format("%.1fK", count / 1000.0)
        else -> count.toString()
    }
}
