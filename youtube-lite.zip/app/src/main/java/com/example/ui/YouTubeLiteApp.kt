package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.ui.screens.home.HomeScreen
import com.example.ui.screens.settings.SettingsScreen
import com.example.ui.screens.shorts.ShortsScreen
import com.example.ui.screens.splash.SplashScreen
import com.example.ui.screens.player.PlayerOverlay
import com.example.ui.screens.search.SearchScreen
import com.example.ui.screens.settings.DownloadsScreen
import com.example.ui.screens.settings.HistoryScreen
import com.example.ui.screens.settings.AppInfoScreen
import com.example.ui.screens.settings.PrivacyPolicyScreen

sealed class Screen(
    val route: String, 
    val title: String, 
    val selectedIcon: @Composable () -> Unit,
    val unselectedIcon: @Composable () -> Unit
) {
    object Splash : Screen("splash", "Splash", { }, { })
    object Home : Screen("home", "Home", { Icon(Icons.Filled.Home, contentDescription = "Home") }, { Icon(Icons.Outlined.Home, contentDescription = "Home") })
    object Shorts : Screen("shorts", "Shorts", { Icon(Icons.Filled.PlayArrow, contentDescription = "Shorts") }, { Icon(Icons.Outlined.PlayArrow, contentDescription = "Shorts") })
    object Settings : Screen("settings", "Settings", { Icon(Icons.Filled.Settings, contentDescription = "Settings") }, { Icon(Icons.Outlined.Settings, contentDescription = "Settings") })
    object Search : Screen("search", "Search", { }, { })
    object Downloads : Screen("downloads", "Downloads", { }, { })
    object History : Screen("history", "History", { }, { })
    object AppInfo : Screen("app_info", "App Info", { }, { })
    object PrivacyPolicy : Screen("privacy_policy", "Privacy Policy", { }, { })
}

@Composable
fun YouTubeLiteApp(
    isDarkMode: Boolean,
    onThemeToggle: (Boolean) -> Unit
) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination
    
    var activeVideoId by remember { mutableStateOf<String?>(null) }
    var isPlayerExpanded by remember { mutableStateOf(false) }
    var videoHistory by remember { mutableStateOf<List<String>>(emptyList()) }
    
    LaunchedEffect(currentDestination?.route) {
        if (activeVideoId != null) {
            isPlayerExpanded = false
        }
    }
    
    val bottomBarScreens = listOf(
        Screen.Home,
        Screen.Shorts,
        Screen.Settings
    )
    
    val showBottomBar = currentDestination?.route in bottomBarScreens.map { it.route }
    
    Box(modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            bottomBar = {
                if (showBottomBar) {
                    NavigationBar(
                        containerColor = MaterialTheme.colorScheme.background,
                        contentColor = MaterialTheme.colorScheme.onBackground,
                        tonalElevation = 0.dp
                    ) {
                        bottomBarScreens.forEach { screen ->
                            val isSelected = currentDestination?.hierarchy?.any { it.route == screen.route } == true
                            NavigationBarItem(
                                icon = if (isSelected) screen.selectedIcon else screen.unselectedIcon,
                                label = { 
                                    Text(
                                        text = screen.title, 
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    ) 
                                },
                                selected = isSelected,
                                onClick = {
                                    navController.navigate(screen.route) {
                                        popUpTo(navController.graph.findStartDestination().id) {
                                            saveState = true
                                        }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = MaterialTheme.colorScheme.onBackground,
                                    unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                    selectedTextColor = MaterialTheme.colorScheme.onBackground,
                                    unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                    indicatorColor = Color.Transparent
                                )
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            NavHost(
                navController = navController,
                startDestination = Screen.Splash.route,
                modifier = Modifier.padding(innerPadding).background(MaterialTheme.colorScheme.background)
            ) {
                composable(Screen.Splash.route) {
                    SplashScreen(
                        onSplashFinished = {
                            navController.navigate(Screen.Home.route) {
                                popUpTo(Screen.Splash.route) { inclusive = true }
                            }
                        }
                    )
                }
                composable(Screen.Home.route) {
                    HomeScreen(
                        onVideoClick = { videoId ->
                            if (activeVideoId != null && activeVideoId != videoId) {
                                videoHistory = videoHistory + activeVideoId!!
                            }
                            activeVideoId = videoId
                            isPlayerExpanded = true
                        },
                        onSearchClick = {
                            navController.navigate(Screen.Search.route)
                        }
                    )
                }
                composable(Screen.Shorts.route) {
                    ShortsScreen()
                }
                composable(Screen.Settings.route) {
                    SettingsScreen(
                        isDarkMode = isDarkMode,
                        onThemeToggle = onThemeToggle,
                        onDownloadsClick = { navController.navigate(Screen.Downloads.route) },
                        onHistoryClick = { navController.navigate(Screen.History.route) },
                        onPrivacyPolicyClick = { navController.navigate(Screen.PrivacyPolicy.route) },
                        onAppInfoClick = { navController.navigate(Screen.AppInfo.route) }
                    )
                }
                composable(Screen.Search.route) {
                    SearchScreen(
                        onBackClick = { navController.popBackStack() },
                        onVideoClick = { videoId ->
                            if (activeVideoId != null && activeVideoId != videoId) {
                                videoHistory = videoHistory + activeVideoId!!
                            }
                            activeVideoId = videoId
                            isPlayerExpanded = true
                        }
                    )
                }
                composable(Screen.Downloads.route) {
                    DownloadsScreen(onBackClick = { navController.popBackStack() })
                }
                composable(Screen.History.route) {
                    HistoryScreen(onBackClick = { navController.popBackStack() })
                }
                composable(Screen.AppInfo.route) {
                    AppInfoScreen(onBackClick = { navController.popBackStack() })
                }
                composable(Screen.PrivacyPolicy.route) {
                    PrivacyPolicyScreen(onBackClick = { navController.popBackStack() })
                }
            }
        }
        
        if (activeVideoId != null) {
            PlayerOverlay(
                videoId = activeVideoId!!,
                isExpanded = isPlayerExpanded,
                hasPrevious = videoHistory.isNotEmpty(),
                onExpand = { isPlayerExpanded = true },
                onMinimize = { isPlayerExpanded = false },
                onClose = { 
                    activeVideoId = null
                    isPlayerExpanded = false
                    videoHistory = emptyList()
                },
                onVideoClick = { recommendedVideoId ->
                    if (activeVideoId != null && activeVideoId != recommendedVideoId) {
                        videoHistory = videoHistory + activeVideoId!!
                    }
                    activeVideoId = recommendedVideoId
                    isPlayerExpanded = true
                },
                onPreviousClick = {
                    if (videoHistory.isNotEmpty()) {
                        val prev = videoHistory.last()
                        videoHistory = videoHistory.dropLast(1)
                        activeVideoId = prev
                        isPlayerExpanded = true
                    }
                }
            )
        }
    }
}
