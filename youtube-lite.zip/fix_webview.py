import re

with open('./app/src/main/java/com/example/ui/screens/player/PlayerScreen.kt', 'r') as f:
    content = f.read()

android_view_replacement = """
            AndroidView(
                factory = { ctx ->
                    @androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
                    val playerView = PlayerView(ctx).apply {
                        player = exoPlayer
                        useController = false
                        layoutParams = android.view.ViewGroup.LayoutParams(
                            android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                            android.view.ViewGroup.LayoutParams.MATCH_PARENT
                        )
                    }
                    playerView
                },
                modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)
            )
"""

# The WebView AndroidView block is quite large, let's find it using string indices
start_idx = content.find('            AndroidView(')
if start_idx != -1:
    end_idx = content.find('            // Player Controls Overlay', start_idx)
    if end_idx != -1:
        content = content[:start_idx] + android_view_replacement + content[end_idx:]

with open('./app/src/main/java/com/example/ui/screens/player/PlayerScreen.kt', 'w') as f:
    f.write(content)
