import re

with open('./app/src/main/java/com/example/ui/screens/player/PlayerScreen.kt', 'r') as f:
    content = f.read()

# Replace the playerModifier logic and Box
new_player_box = """
        if (!isExpanded) {
            // Official YouTube Style Mini-Player Bar
            Row(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 80.dp) // Above bottom nav
                    .fillMaxWidth()
                    .height(60.dp)
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .clickable { onExpand() },
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Mini Video Player
                Box(
                    modifier = Modifier
                        .width(106.dp)
                        .fillMaxHeight()
                        .background(Color.Black)
                ) {
                    AndroidView(
                        factory = { ctx ->
                            @androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
                            val playerView = PlayerView(ctx).apply {
                                player = exoPlayer
                                useController = false
                                layoutParams = android.view.ViewGroup.LayoutParams(
                                    android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                                    android.view.ViewGroup.LayoutParams.MATCH_PARENT
                                )
                            }
                            playerView
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                }
                
                // Title
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 12.dp)
                ) {
                    Text(
                        text = videoDetails?.snippet?.title ?: "Video Playing",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground,
                        maxLines = 1,
                        overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                    )
                    Text(
                        text = videoDetails?.snippet?.channelTitle ?: "YouTube",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                    )
                }
                
                // Controls
                IconButton(
                    onClick = { isPlaying = !isPlaying }
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                        contentDescription = if (isPlaying) "Pause" else "Play",
                        tint = MaterialTheme.colorScheme.onBackground
                    )
                }
                IconButton(onClick = onClose) {
                    Icon(
                        imageVector = Icons.Filled.Close,
                        contentDescription = "Close",
                        tint = MaterialTheme.colorScheme.onBackground
                    )
                }
            }
        } else {
            // Expanded Player
            val playerModifier = if (isFullscreen) {
                Modifier.fillMaxSize()
            } else {
                Modifier.fillMaxWidth().aspectRatio(16f / 9f).align(Alignment.TopCenter)
            }
            
            Box(
                modifier = playerModifier
                    .clickable { showControls = !showControls },
                contentAlignment = Alignment.Center
            ) {
                AndroidView(
                    factory = { ctx ->
                        @androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
                        val playerView = PlayerView(ctx).apply {
                            player = exoPlayer
                            useController = false
                            layoutParams = android.view.ViewGroup.LayoutParams(
                                android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                                android.view.ViewGroup.LayoutParams.MATCH_PARENT
                            )
                        }
                        playerView
                    },
                    modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)
                )

                // Player Controls Overlay
                if (showControls) {
                    // Dim background
                    Box(modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background.copy(alpha = 0.4f)))
                    
                    Row(
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
"""

# We need to find the start of `val playerModifier = if (!isExpanded) {`
# And replace up to the point where the `Row` for controls starts.
start_idx = content.find('        val playerModifier = if (!isExpanded) {')
end_idx = content.find('                    Row(', content.find('// Dim background'))
if start_idx != -1 and end_idx != -1:
    content = content[:start_idx] + new_player_box + content[end_idx + 24:]

# Also replace the trailing curly braces logic for the Box at the end of the file.
# Since we wrapped the Expanded player in `if (isExpanded) { ... }`, we might have mismatched brackets.
# Let's just fix it manually.
with open('./app/src/main/java/com/example/ui/screens/player/PlayerScreen.kt', 'w') as f:
    f.write(content)

