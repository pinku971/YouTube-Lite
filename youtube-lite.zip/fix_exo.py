import re

def fix_file(path):
    with open(path, 'r') as f:
        content = f.read()

    # We will look for AndroidView block and replace it correctly
    
    # First, let's fix the broken parts if any
    
    # Let's replace the whole mini player AndroidView
    pattern1 = r'AndroidView\([^}]+?\}\s*,\s*modifier = Modifier\.fillMaxSize[^\n]*\n.*?\)'
    
    replacement1 = """AndroidView(
                        factory = { ctx ->
                            @androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
                            val playerView = PlayerView(ctx).apply {
                                player = exoPlayer
                                useController = false
                                layoutParams = android.view.ViewGroup.LayoutParams(
                                    android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                                    android.view.ViewGroup.LayoutParams.MATCH_PARENT
                                )
                            }
                            playerView
                        },
                        modifier = Modifier.fillMaxSize(),
                        update = { it.player = exoPlayer }
                    )"""

    # There are two in PlayerScreen, one in ShortVideoPlayer
    
    # Let's just do a manual find and replace that targets the factory = { ctx -> ... }
    
    def replace_android_view(match):
        return """AndroidView(
                    factory = { ctx ->
                        @androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
                        val playerView = PlayerView(ctx).apply {
                            player = exoPlayer
                            useController = false
                            layoutParams = android.view.ViewGroup.LayoutParams(
                                android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                                android.view.ViewGroup.LayoutParams.MATCH_PARENT
                            )
                        }
                        playerView
                    },
                    modifier = Modifier.fillMaxSize(),
                    update = { it.player = exoPlayer }
                )"""

    content = re.sub(r'AndroidView\(\s*factory = \{ ctx ->.*?playerView\s*\},\s*modifier =.*?\n\s*\)', replace_android_view, content, flags=re.DOTALL)
    
    # But wait, one of them has background(MaterialTheme.colorScheme.background)
    
    with open(path, 'w') as f:
        f.write(content)

fix_file('app/src/main/java/com/example/ui/screens/player/PlayerScreen.kt')
# ShortVideoPlayer doesn't have @androidx.annotation.OptIn, we need a slightly different regex

with open('app/src/main/java/com/example/ui/components/ShortVideoPlayer.kt', 'r') as f:
    content = f.read()

# For ShortVideoPlayer
content = re.sub(r'AndroidView\(\s*factory = \{ ctx ->\s*PlayerView\(ctx\)\.apply \{.*?\}.*?\},\s*modifier =.*?\)', 
"""AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    player = exoPlayer
                    useController = false
                    layoutParams = android.view.ViewGroup.LayoutParams(
                        android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                        android.view.ViewGroup.LayoutParams.MATCH_PARENT
                    )
                }
            },
            modifier = Modifier.fillMaxSize(),
            update = { it.player = exoPlayer }
        )""", content, flags=re.DOTALL)

with open('app/src/main/java/com/example/ui/components/ShortVideoPlayer.kt', 'w') as f:
    f.write(content)
