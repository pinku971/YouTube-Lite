with open('./app/src/main/java/com/example/ui/screens/player/PlayerScreen.kt', 'r') as f:
    content = f.read()

content = content.replace('ModalBottomSheet(onDismissRequest = { isDescriptionSheetOpen = false })', 'ModalBottomSheet(onDismissRequest = { isDescriptionSheetOpen = false }, dragHandle = null, containerColor = MaterialTheme.colorScheme.background)')
content = content.replace('ModalBottomSheet(onDismissRequest = { isCommentsSheetOpen = false })', 'ModalBottomSheet(onDismissRequest = { isCommentsSheetOpen = false }, dragHandle = null, containerColor = MaterialTheme.colorScheme.background)')

with open('./app/src/main/java/com/example/ui/screens/player/PlayerScreen.kt', 'w') as f:
    f.write(content)
