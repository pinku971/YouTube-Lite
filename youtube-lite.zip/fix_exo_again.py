import re

for path in ['app/src/main/java/com/example/ui/screens/player/PlayerScreen.kt', 'app/src/main/java/com/example/ui/components/ShortVideoPlayer.kt']:
    with open(path, 'r') as f:
        content = f.read()

    # Revert the mess
    content = re.sub(r'modifier = Modifier\.fillMaxSize\([^\)]*\)\.background\([^\)]*\)\s*,\s*update = \{ it\.player = exoPlayer \}\s*\)', 'modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background),\n                    update = { it.player = exoPlayer }\n                )', content)
    content = re.sub(r'modifier = Modifier\.fillMaxSize\([^\)]*\)\s*,\s*update = \{ it\.player = exoPlayer \}\s*\)', 'modifier = Modifier.fillMaxSize(),\n                    update = { it.player = exoPlayer }\n                )', content)

    # I'll just manually replace the whole AndroidView blocks using string replacement
    
    with open(path, 'w') as f:
        f.write(content)

