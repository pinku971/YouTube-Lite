import re

with open('./app/src/main/java/com/example/ui/screens/search/SearchScreen.kt', 'r') as f:
    content = f.read()

content = content.replace('RetrofitClient.apiService.searchVideos(query = query, apiKey = apiKey)', 'RetrofitClient.apiService.searchVideos(query = query)')

with open('./app/src/main/java/com/example/ui/screens/search/SearchScreen.kt', 'w') as f:
    f.write(content)
