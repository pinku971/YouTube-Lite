import re

with open('./app/src/main/java/com/example/ui/screens/player/PlayerScreen.kt', 'r') as f:
    content = f.read()

# Add empty check for videoId
target = "RetrofitClient.apiService.getVideoDetails(id = videoId)"
replacement = """if (videoId.isBlank()) throw Exception("Invalid Video ID")
                RetrofitClient.apiService.getVideoDetails(id = videoId)"""
if target in content:
    content = content.replace(target, replacement)
else:
    print("Not found")

with open('./app/src/main/java/com/example/ui/screens/player/PlayerScreen.kt', 'w') as f:
    f.write(content)
