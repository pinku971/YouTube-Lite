import re

with open('./app/src/main/java/com/example/ui/screens/shorts/ShortsScreen.kt', 'r') as f:
    content = f.read()

old_loading = """            isLoading -> {
                CircularProgressIndicator(modifier = Modifier.align(Alignment.Center), color = MaterialTheme.colorScheme.onBackground)
            }"""

new_loading = """            isLoading -> {
                com.example.ui.screens.shorts.ShortsSkeleton()
            }"""

if old_loading in content:
    content = content.replace(old_loading, new_loading)
else:
    print("Could not find the loading block in ShortsScreen")

with open('./app/src/main/java/com/example/ui/screens/shorts/ShortsScreen.kt', 'w') as f:
    f.write(content)
