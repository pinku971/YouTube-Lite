import re

with open('./app/src/main/java/com/example/ui/screens/player/PlayerScreen.kt', 'r') as f:
    content = f.read()

# Remove webViewRef declaration
content = re.sub(r'\s*var webViewRef by remember \{ mutableStateOf<WebView\?>\(null\) \}', '', content)

# Remove evaluateJavascript call
content = re.sub(r'\s*webViewRef\?\.evaluateJavascript.*', '', content)

with open('./app/src/main/java/com/example/ui/screens/player/PlayerScreen.kt', 'w') as f:
    f.write(content)
