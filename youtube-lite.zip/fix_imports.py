with open('./app/src/main/java/com/example/ui/screens/player/PlayerScreen.kt', 'r') as f:
    content = f.read()

imports_to_add = """
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material3.Divider
"""

for imp in imports_to_add.strip().split('\n'):
    if imp not in content:
        content = content.replace('import androidx.compose.ui.Modifier', 'import androidx.compose.ui.Modifier\n' + imp)

with open('./app/src/main/java/com/example/ui/screens/player/PlayerScreen.kt', 'w') as f:
    f.write(content)
