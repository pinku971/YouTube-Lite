import re

with open('./app/src/main/java/com/example/ui/screens/player/PlayerScreen.kt', 'r') as f:
    content = f.read()

content = content.replace('RetrofitClient.apiService.getVideoDetails(id = videoId, apiKey = apiKey)', 'RetrofitClient.apiService.getVideoDetails(id = videoId)')
content = content.replace('RetrofitClient.apiService.searchVideos(query = videoDetails?.snippet?.title ?: "Music", apiKey = apiKey)', 'RetrofitClient.apiService.searchVideos(query = videoDetails?.snippet?.title ?: "Music")')

with open('./app/src/main/java/com/example/ui/screens/player/PlayerScreen.kt', 'w') as f:
    f.write(content)
