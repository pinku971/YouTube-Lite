import re

def update_url(path):
    with open(path, 'r') as f:
        content = f.read()

    # Replace dead URL with working one
    content = re.sub(
        r'"https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/[^"]+"',
        r'"https://storage.googleapis.com/exoplayer-test-media-0/BigBuckBunny_320x180.mp4"',
        content
    )

    with open(path, 'w') as f:
        f.write(content)

update_url('app/src/main/java/com/example/ui/screens/player/PlayerScreen.kt')
update_url('app/src/main/java/com/example/ui/components/ShortVideoPlayer.kt')
