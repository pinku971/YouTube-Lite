import re

with open('./app/src/main/java/com/example/ui/screens/shorts/ShortsScreen.kt', 'r') as f:
    content = f.read()

content = content.replace('RetrofitClient.apiService.searchVideos(query = "#shorts", apiKey = apiKey)', 'RetrofitClient.apiService.searchVideos(query = "#shorts")')

with open('./app/src/main/java/com/example/ui/screens/shorts/ShortsScreen.kt', 'w') as f:
    f.write(content)
