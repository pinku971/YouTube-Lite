def update_file(filepath):
    with open(filepath, 'r') as f:
        content = f.read()

    # Update initialization
    content = content.replace('''        ExoPlayer.Builder(context).build().apply {
            repeatMode = Player.REPEAT_MODE_ONE
        }''', '''        ExoPlayer.Builder(context).build().apply {
            repeatMode = Player.REPEAT_MODE_ONE
            playWhenReady = isPlaying
        }''')
    
    content = content.replace('''        ExoPlayer.Builder(context).build().apply {
            repeatMode = Player.REPEAT_MODE_ALL
        }''', '''        ExoPlayer.Builder(context).build().apply {
            repeatMode = Player.REPEAT_MODE_ALL
            playWhenReady = isPlaying
        }''')

    # Update LaunchedEffect(videoId)
    content = content.replace('''    LaunchedEffect(videoId) {
        val mediaItem = MediaItem.fromUri(Uri.parse(videoUri))
        exoPlayer.setMediaItem(mediaItem)
        exoPlayer.prepare()
        if (isPlaying) exoPlayer.play()
    }''', '''    LaunchedEffect(videoId) {
        val mediaItem = MediaItem.fromUri(Uri.parse(videoUri))
        exoPlayer.setMediaItem(mediaItem)
        exoPlayer.prepare()
        exoPlayer.playWhenReady = isPlaying
    }''')
    
    content = content.replace('''    LaunchedEffect(videoId) {
        val mediaItem = MediaItem.fromUri(Uri.parse(videoUri))
        exoPlayer.setMediaItem(mediaItem)
        exoPlayer.prepare()
    }''', '''    LaunchedEffect(videoId) {
        val mediaItem = MediaItem.fromUri(Uri.parse(videoUri))
        exoPlayer.setMediaItem(mediaItem)
        exoPlayer.prepare()
        exoPlayer.playWhenReady = isPlaying
    }''')

    # Update LaunchedEffect(isPlaying)
    content = content.replace('''    LaunchedEffect(isPlaying) {
        if (isPlaying) {
            exoPlayer.play()
        } else {
            exoPlayer.pause()
        }
    }''', '''    LaunchedEffect(isPlaying) {
        exoPlayer.playWhenReady = isPlaying
    }''')
    
    with open(filepath, 'w') as f:
        f.write(content)

update_file('./app/src/main/java/com/example/ui/components/ShortVideoPlayer.kt')
update_file('./app/src/main/java/com/example/ui/screens/player/PlayerScreen.kt')
