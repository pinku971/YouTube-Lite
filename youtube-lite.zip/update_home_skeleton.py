import re

with open('./app/src/main/java/com/example/ui/screens/home/HomeScreen.kt', 'r') as f:
    content = f.read()

# Replace CircularProgressIndicator with LazyColumn of VideoItemSkeleton
old_loading = """                isLoading -> {
                    CircularProgressIndicator(
                        modifier = Modifier.align(Alignment.Center),
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }"""

new_loading = """                isLoading -> {
                    androidx.compose.foundation.lazy.LazyColumn(modifier = Modifier.fillMaxSize()) {
                        items(5) {
                            com.example.ui.components.VideoItemSkeleton()
                        }
                    }
                }"""

if old_loading in content:
    content = content.replace(old_loading, new_loading)
else:
    print("Could not find the loading block in HomeScreen")

with open('./app/src/main/java/com/example/ui/screens/home/HomeScreen.kt', 'w') as f:
    f.write(content)
