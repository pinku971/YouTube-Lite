with open('./app/src/main/java/com/example/ui/screens/player/PlayerScreen.kt', 'r') as f:
    content = f.read()

# Fix play/pause
content = content.replace('''                            isPlaying = !isPlaying
                            val command = if (isPlaying) "playVideo" else "pauseVideo"
                            webViewRef?.evaluateJavascript("document.querySelector('iframe').contentWindow.postMessage('{\"event\":\"command\",\"func\":\"$command\",\"args\":\"\"}', '*');", null)''', '                            isPlaying = !isPlaying')

# Add BackHandler
if 'BackHandler(enabled = isExpanded)' not in content:
    content = content.replace('@Composable\nfun PlayerOverlay(', '@Composable\nfun PlayerOverlay(')
    content = content.replace('    var offsetY by remember { mutableStateOf(0f) }', '    var offsetY by remember { mutableStateOf(0f) }\n\n    BackHandler(enabled = isExpanded) {\n        onMinimize()\n    }')

# Add Minimize Icon
minimize_icon_code = """
                if (isExpanded && !isFullscreen) {
                    IconButton(
                        onClick = onMinimize,
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(8.dp)
                    ) {
                        Icon(
                            imageVector = androidx.compose.material.icons.Icons.Default.Close,
                            contentDescription = "Minimize",
                            tint = MaterialTheme.colorScheme.onBackground
                        )
                    }
                }
"""

if 'if (isExpanded && !isFullscreen)' not in content:
    content = content.replace('                    // Fullscreen toggle', minimize_icon_code + '\n                    // Fullscreen toggle')

with open('./app/src/main/java/com/example/ui/screens/player/PlayerScreen.kt', 'w') as f:
    f.write(content)
