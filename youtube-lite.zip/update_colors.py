import re

files_to_update = [
    './app/src/main/java/com/example/ui/components/ShortVideoPlayer.kt',
    './app/src/main/java/com/example/ui/components/VideoItemCard.kt'
]

for file in files_to_update:
    with open(file, 'r') as f:
        content = f.read()
    
    if "ShortVideoPlayer" in file:
        content = content.replace('.background(Color.Black)', '.background(androidx.compose.material3.MaterialTheme.colorScheme.background)')
    
    if "VideoItemCard" in file:
        content = content.replace('Color.Black.copy(alpha = 0.8f)', 'androidx.compose.material3.MaterialTheme.colorScheme.background.copy(alpha = 0.8f)')
    
    with open(file, 'w') as f:
        f.write(content)
