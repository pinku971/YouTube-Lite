import re

with open('./app/src/main/java/com/example/ui/screens/search/SearchScreen.kt', 'r') as f:
    content = f.read()

content = content.replace('val apiKey = BuildConfig.YOUTUBE_API_KEY', '')
content = content.replace('if (apiKey == "MY_YOUTUBE_API_KEY" || apiKey.isBlank()) {', 'if (BuildConfig.YOUTUBE_API_KEY == "MY_YOUTUBE_API_KEY" || BuildConfig.YOUTUBE_API_KEY.isBlank()) {')

with open('./app/src/main/java/com/example/ui/screens/search/SearchScreen.kt', 'w') as f:
    f.write(content)
