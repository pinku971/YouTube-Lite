import re

with open('./app/src/main/java/com/example/ui/screens/home/HomeScreen.kt', 'r') as f:
    content = f.read()

content = content.replace('RetrofitClient.apiService.getPopularVideos(apiKey = apiKey)', 'RetrofitClient.apiService.getPopularVideos()')
content = content.replace('RetrofitClient.apiService.searchVideos(query = currentCategory, apiKey = apiKey)', 'RetrofitClient.apiService.searchVideos(query = currentCategory)')

with open('./app/src/main/java/com/example/ui/screens/home/HomeScreen.kt', 'w') as f:
    f.write(content)
