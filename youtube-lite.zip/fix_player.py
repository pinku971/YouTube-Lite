with open('./app/src/main/java/com/example/ui/screens/player/PlayerScreen.kt', 'r') as f:
    content = f.read()

content = content.replace('    val exoPlayer = remember {', '    val context = LocalContext.current\n    val exoPlayer = remember {')
content = content.replace('    val context = LocalContext.current\n    var isFullscreen by remember { mutableStateOf(false) }', '    var isFullscreen by remember { mutableStateOf(false) }')

with open('./app/src/main/java/com/example/ui/screens/player/PlayerScreen.kt', 'w') as f:
    f.write(content)
